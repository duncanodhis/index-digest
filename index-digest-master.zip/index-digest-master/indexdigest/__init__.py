"""
index_digest Python module
"""
VERSION = '1.5.0'
